// Select the button and add a click event
document.getElementById("alertButton").addEventListener("click", function() {
  alert("Hello Varsha! You just clicked the button 🎉");
});
