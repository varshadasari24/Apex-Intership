// Select elements
const taskInput = document.getElementById("taskInput");
const addTaskBtn = document.getElementById("addTaskBtn");
const taskList = document.getElementById("taskList");
const clearAllBtn = document.getElementById("clearAll");

// Load tasks from localStorage on page load
document.addEventListener("DOMContentLoaded", loadTasks);

// Add new task
addTaskBtn.addEventListener("click", addTask);

// Clear all tasks
clearAllBtn.addEventListener("click", clearAllTasks);

// Add task function
function addTask() {
  const taskText = taskInput.value.trim();
  if (taskText === "") {
    alert("Please enter a task!");
    return;
  }

  const task = {
    text: taskText,
    completed: false
  };

  const tasks = getTasks();
  tasks.push(task);
  saveTasks(tasks);

  displayTask(task);
  taskInput.value = "";
}

// Display single task
function displayTask(task) {
  const li = document.createElement("li");
  li.textContent = task.text;
  if (task.completed) li.classList.add("completed");

  // Toggle complete
  li.addEventListener("click", () => {
    li.classList.toggle("completed");
    task.completed = !task.completed;
    updateTask(task.text, task.completed);
  });

  // Delete button
  const deleteBtn = document.createElement("button");
  deleteBtn.textContent = "Delete";
  deleteBtn.classList.add("delete-btn");
  deleteBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    deleteTask(task.text);
    li.remove();
  });

  li.appendChild(deleteBtn);
  taskList.appendChild(li);
}

// Load tasks from localStorage
function loadTasks() {
  const tasks = getTasks();
  tasks.forEach(displayTask);
}

// Get tasks from localStorage
function getTasks() {
  return JSON.parse(localStorage.getItem("tasks")) || [];
}

// Save tasks to localStorage
function saveTasks(tasks) {
  localStorage.setItem("tasks", JSON.stringify(tasks));
}

// Update task completion in localStorage
function updateTask(taskText, completed) {
  const tasks = getTasks();
  const updatedTasks = tasks.map(t =>
    t.text === taskText ? { ...t, completed } : t
  );
  saveTasks(updatedTasks);
}

// Delete task from localStorage
function deleteTask(taskText) {
  const tasks = getTasks();
  const filteredTasks = tasks.filter(t => t.text !== taskText);
  saveTasks(filteredTasks);
}

// Clear all tasks
function clearAllTasks() {
  localStorage.removeItem("tasks");
  taskList.innerHTML = "";
}
