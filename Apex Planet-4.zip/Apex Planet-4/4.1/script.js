document.getElementById("year").textContent = new Date().getFullYear();

document.getElementById("toggle").addEventListener("click", () => {
  const menu = document.getElementById("menu");
  menu.style.display = menu.style.display === "flex" ? "none" : "flex";
});
