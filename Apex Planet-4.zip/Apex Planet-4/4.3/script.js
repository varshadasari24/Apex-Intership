const products = [
  { id: 1, name: "Smartphone", category: "electronics", price: 15000, rating: 4.5, img: "https://cdn-icons-png.flaticon.com/512/3405/3405244.png" },
  { id: 2, name: "T-Shirt", category: "fashion", price: 800, rating: 4.0, img: "https://cdn-icons-png.flaticon.com/512/892/892458.png" },
  { id: 3, name: "Laptop", category: "electronics", price: 55000, rating: 4.8, img: "https://cdn-icons-png.flaticon.com/512/2933/2933245.png" },
  { id: 4, name: "Sofa", category: "home", price: 12000, rating: 4.3, img: "https://cdn-icons-png.flaticon.com/512/706/706164.png" },
  { id: 5, name: "Jeans", category: "fashion", price: 2000, rating: 4.2, img: "https://cdn-icons-png.flaticon.com/512/892/892467.png" },
  { id: 6, name: "Headphones", category: "electronics", price: 1200, rating: 4.4, img: "https://cdn-icons-png.flaticon.com/512/747/747376.png" },
  { id: 7, name: "Mixer Grinder", category: "home", price: 2500, rating: 4.1, img: "https://cdn-icons-png.flaticon.com/512/2593/2593766.png" },
  { id: 8, name: "Dress", category: "fashion", price: 1800, rating: 4.7, img: "https://cdn-icons-png.flaticon.com/512/892/892501.png" }
];

const productContainer = document.getElementById("productContainer");
const categoryFilter = document.getElementById("categoryFilter");
const priceFilter = document.getElementById("priceFilter");
const sortBy = document.getElementById("sortBy");

// Display all products initially
displayProducts(products);

categoryFilter.addEventListener("change", applyFilters);
priceFilter.addEventListener("change", applyFilters);
sortBy.addEventListener("change", applyFilters);

// Function to display products
function displayProducts(filteredProducts) {
  productContainer.innerHTML = "";

  if (filteredProducts.length === 0) {
    productContainer.innerHTML = "<p>No products found.</p>";
    return;
  }

  filteredProducts.forEach(p => {
    const card = document.createElement("div");
    card.classList.add("product-card");

    card.innerHTML = `
      <img src="${p.img}" alt="${p.name}">
      <h3>${p.name}</h3>
      <p class="price">₹${p.price}</p>
      <p>Category: ${p.category}</p>
      <p class="rating">⭐ ${p.rating}</p>
    `;

    productContainer.appendChild(card);
  });
}

// Apply filters and sorting
function applyFilters() {
  let filtered = [...products];

  // Filter by category
  const selectedCategory = categoryFilter.value;
  if (selectedCategory !== "all") {
    filtered = filtered.filter(p => p.category === selectedCategory);
  }

  // Filter by price range
  const selectedPrice = priceFilter.value;
  if (selectedPrice === "low") {
    filtered = filtered.filter(p => p.price < 1000);
  } else if (selectedPrice === "medium") {
    filtered = filtered.filter(p => p.price >= 1000 && p.price <= 5000);
  } else if (selectedPrice === "high") {
    filtered = filtered.filter(p => p.price > 5000);
  }

  // Sorting
  const sortOption = sortBy.value;
  if (sortOption === "priceLowHigh") {
    filtered.sort((a, b) => a.price - b.price);
  } else if (sortOption === "priceHighLow") {
    filtered.sort((a, b) => b.price - a.price);
  } else if (sortOption === "ratingHighLow") {
    filtered.sort((a, b) => b.rating - a.rating);
  }

  displayProducts(filtered);
}
