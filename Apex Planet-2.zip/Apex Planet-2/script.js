// Select the form
const form = document.getElementById('contactForm');

// Form submit event
form.addEventListener('submit', function(e) {
    e.preventDefault(); // prevent default submission

    // Get form values
    const name = document.getElementById('name').value.trim();
    const email = document.getElementById('email').value.trim();
    const subject = document.getElementById('subject').value.trim();
    const message = document.getElementById('message').value.trim();

    // Validate inputs
    if (name === "" || email === "" || subject === "" || message === "") {
        alert("⚠️ Please fill out all fields before submitting!");
        return;
    }

    // Validate email format
    if (!validateEmail(email)) {
        alert("❌ Please enter a valid email address!");
        return;
    }

    // Success message
    alert("✅ Your message has been sent successfully!");

    // Reset form after successful submission
    form.reset();
});

// Function to check email pattern
function validateEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}
