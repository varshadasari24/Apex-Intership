const products = [
  { id: 1, name: "Smartphone", category: "electronics", price: 29999, rating: 4.5, img: "assets/images/phone.png" },
  { id: 2, name: "Sneakers", category: "fashion", price: 2499, rating: 4.2, img: "assets/images/shoes.png" },
  { id: 3, name: "Coffee Maker", category: "home", price: 4999, rating: 4.7, img: "assets/images/coffee.png" },
  { id: 4, name: "Bluetooth Speaker", category: "electronics", price: 1499, rating: 4.1, img: "assets/images/speaker.png" },
  { id: 5, name: "T-Shirt", category: "fashion", price: 899, rating: 4.3, img: "assets/images/tshirt.png" },
];

const productContainer = document.getElementById("productContainer");
const categoryFilter = document.getElementById("categoryFilter");
const sortBy = document.getElementById("sortBy");
const cartCount = document.getElementById("cart-count");

// Load cart count from localStorage
updateCartCount();

// Initial display
displayProducts(products);

// Event listeners
categoryFilter.addEventListener("change", applyFilters);
sortBy.addEventListener("change", applyFilters);

function displayProducts(items) {
  productContainer.innerHTML = "";
  items.forEach(p => {
    const card = document.createElement("div");
    card.classList.add("product-card");
    card.innerHTML = `
      <img src="${p.img}" alt="${p.name}" loading="lazy">
      <div class="product-info">
        <h3>${p.name}</h3>
        <p class="price">₹${p.price}</p>
        <p>⭐ ${p.rating}</p>
        <button onclick="addToCart(${p.id})">Add to Cart</button>
      </div>
    `;
    productContainer.appendChild(card);
  });
}

function applyFilters() {
  let filtered = [...products];

  // Filter by category
  const category = categoryFilter.value;
  if (category !== "all") {
    filtered = filtered.filter(p => p.category === category);
  }

  // Sort by criteria
  const sortValue = sortBy.value;
  if (sortValue === "priceLowHigh") filtered.sort((a,b) => a.price - b.price);
  if (sortValue === "priceHighLow") filtered.sort((a,b) => b.price - a.price);
  if (sortValue === "ratingHighLow") filtered.sort((a,b) => b.rating - a.rating);

  displayProducts(filtered);
}

function addToCart(id) {
  const selected = products.find(p => p.id === id);
  let cart = JSON.parse(localStorage.getItem("cart")) || [];
  cart.push(selected);
  localStorage.setItem("cart", JSON.stringify(cart));
  updateCartCount();
  alert(`${selected.name} added to cart!`);
}

function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem("cart")) || [];
  cartCount.textContent = cart.length;
}
