const getJokeBtn = document.getElementById("getJoke");
const jokeText = document.getElementById("joke");

getJokeBtn.addEventListener("click", fetchJoke);

async function fetchJoke() {
  const res = await fetch("https://official-joke-api.appspot.com/random_joke");
  const data = await res.json();
  jokeText.innerHTML = `${data.setup} — <strong>${data.punchline}</strong>`;
}
