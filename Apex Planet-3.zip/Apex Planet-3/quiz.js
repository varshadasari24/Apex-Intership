const quizData = [
  {
    question: "1. Which HTML tag is used for JavaScript?",
    a: "<js>",
    b: "<script>",
    c: "<javascript>",
    correct: "b"
  },
  {
    question: "2. What does CSS stand for?",
    a: "Colorful Style Sheet",
    b: "Creative Style Sheet",
    c: "Cascading Style Sheet",
    correct: "c"
  },
  {
    question: "3. Inside which HTML element do we put the CSS?",
    a: "<style>",
    b: "<css>",
    c: "<design>",
    correct: "a"
  }
];

const quiz = document.getElementById("quiz");
const submitBtn = document.getElementById("submit");
const result = document.getElementById("result");

let current = 0;
let score = 0;

function loadQuiz() {
  const q = quizData[current];
  quiz.innerHTML = `
    <h3>${q.question}</h3>
    <label><input type="radio" name="answer" value="a"> ${q.a}</label><br>
    <label><input type="radio" name="answer" value="b"> ${q.b}</label><br>
    <label><input type="radio" name="answer" value="c"> ${q.c}</label><br>
  `;
}

submitBtn.addEventListener("click", () => {
  const answer = document.querySelector('input[name="answer"]:checked');
  if (!answer) return alert("Please select an answer!");

  if (answer.value === quizData[current].correct) score++;

  current++;

  if (current < quizData.length) {
    loadQuiz();
  } else {
    result.textContent = `✅ You got ${score} out of ${quizData.length} correct!`;
    quiz.innerHTML = "";
    submitBtn.style.display = "none";
  }
});

loadQuiz();
